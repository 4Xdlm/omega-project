# OMEGA ARCHITECTURE v3.30.0

```
╔═══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                       ║
║   OMEGA PROJECT — ARCHITECTURE DOCUMENT                                               ║
║   Version: v3.30.0                                                                    ║
║   Date: 2026-01-09                                                                    ║
║                                                                                       ║
╚═══════════════════════════════════════════════════════════════════════════════════════╝
```

---

## ARCHITECTURE HIÉRARCHIQUE

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        MONDE EXTÉRIEUR                                      │
│                 (données brutes, hétérogènes, non fiables)                  │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      MYCELIUM v1.0.0 (Phase 29.2 — FROZEN)                  │
│                                                                             │
│   Rôle: Validation d'entrée, Normalisation, Rejet déterministe             │
│                                                                             │
│   • 12 invariants INV-MYC-*                                                 │
│   • 20 codes de rejet REJ-MYC-*                                             │
│   • 5 gates bloquants GATE-MYC-*                                            │
│   • 97 tests                                                                │
│                                                                             │
│   Seal: c0b9b859d21c51f4d2c3e0090c3c40d3423c109e9fa6b882ecc954238d2f270f    │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │
                        ╔═══════════╧═══════════╗
                        ║  FRONTIÈRE FORMELLE   ║
                        ║  (4 INV-BOUND-*)      ║
                        ╚═══════════╤═══════════╝
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      GENOME v1.2.0 (Phase 28 — SEALED)                      │
│                                                                             │
│   Rôle: Analyse émotionnelle, Fingerprint SHA-256                           │
│                                                                             │
│   • 14 invariants INV-GEN-*                                                 │
│   • Fingerprint SHA-256 déterministe                                        │
│   • Emotion14 sanctuarisé                                                   │
│   • CERTIFIED BY SENTINEL                                                   │
│   • 109 tests                                                               │
│                                                                             │
│   Golden Hash: 172f970a3b2bb5713743d0cd3ecf2d7537699cba5694a3e6946b786f5e21 │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      SENTINEL (Phase 27 — ROOT / JUDGE)                     │
│                                                                             │
│   Rôle: Falsification, Self-Seal, Audit, Certification                      │
│                                                                             │
│   • 101 invariants (87 Sentinel + 14 Genome)                                │
│   • 37 attaques (32 Sentinel + 5 Genome)                                    │
│   • Self-Seal v1.0.0                                                        │
│   • 927 tests                                                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## RÈGLES ARCHITECTURALES

| Règle | Description |
|-------|-------------|
| **R1** | Flux unidirectionnel (haut → bas) |
| **R2** | Client ne modifie jamais son patron |
| **R3** | Rejet = terminal, pas de mode dégradé |
| **R4** | Chaque module = autonome + testable isolément |
| **R5** | Frontières = contrats formels (INV-BOUND-*) |

---

## MODULES

| Module | Package | Version | Tests | Status |
|--------|---------|---------|-------|--------|
| Mycelium | @omega/mycelium | v1.0.0 | 97 | 🔒 FROZEN |
| Genome | @omega/genome | v1.2.0 | 109 | 🔒 SEALED |
| Sentinel | OMEGA_SENTINEL_SUPREME | v3.27.0 | 927 | 🔒 FROZEN |

---

## INVARIANTS PAR COUCHE

| Couche | Invariants | Description |
|--------|------------|-------------|
| Mycelium | INV-MYC-01..12 | Validation entrée |
| Boundary | INV-BOUND-01..04 | Frontière formelle |
| Genome | INV-GEN-01..14 | Analyse émotionnelle |
| Sentinel | INV-xxx (87) | Falsification |

---

## PROCHAINE INTÉGRATION (Phase 29.3)

```
Mycelium.validate(input)
    │
    ├── REJECT → Stop (REJ-MYC-xxx)
    │
    └── ACCEPT → Genome.analyze(validatedInput)
                     │
                     └── Result (fingerprint, emotions)
```
