/**
 * OMEGA GATEWAY — Entry Point
 * Phase 17 — Unified Security Gateway Facade
 */

export * from './gateway/index.js';
