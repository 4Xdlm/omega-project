/**
 * OMEGA QUARANTINE_V2 — Entry Point
 * Phase 16.2 — Isolation Chamber
 */

export * from './quarantine/index.js';
