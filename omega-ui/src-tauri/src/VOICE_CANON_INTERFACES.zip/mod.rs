﻿//! OMEGA CANON — Interface Module
//! Version: v1.0.0-CERTIFIED

mod contract;

pub use contract::*;
